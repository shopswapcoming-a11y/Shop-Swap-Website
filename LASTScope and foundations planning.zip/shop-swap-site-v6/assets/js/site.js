/* Shop Swap — front-end behaviour. No framework. Demo state lives in localStorage (guarded). */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var PAGE = (document.body.className.match(/pg-([\w-]+)/) || [])[1] || '';

  function store(k, v) {
    try {
      if (v === undefined) { var x = localStorage.getItem('ss:' + k); return x ? JSON.parse(x) : null; }
      localStorage.setItem('ss:' + k, JSON.stringify(v));
    } catch (e) { /* storage unavailable: keep working without it */ }
    return null;
  }
  function onKey(el, fn) {
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fn(e); }
    });
  }
  function visibleRoot() {
    var p = $('.vp-phone'), d = $('.vp-desk');
    return (p && getComputedStyle(p).display !== 'none') ? p : (d || document.body);
  }
  function textNodes(root, re, fn) {
    var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), n, list = [];
    while ((n = w.nextNode())) if (re.test(n.nodeValue)) list.push(n);
    list.forEach(function (t) { t.nodeValue = t.nodeValue.replace(re, fn); });
  }
  function errorFor(el, msg) {
    clearError(el);
    var host = el.closest('[data-field]') || el;
    host.style.borderColor = '#FF3C00';
    el.setAttribute('aria-invalid', 'true');
    var d = document.createElement('div');
    d.className = 'err'; d.setAttribute('role', 'alert');
    d.style.cssText = "font:400 13.5px/1.45 'Helvetica Neue',Helvetica,Arial,sans-serif;color:rgba(0,0,0,.8);margin-top:8px";
    d.textContent = msg;
    host.insertAdjacentElement('afterend', d);
    el.__err = d;
  }
  function clearError(el) {
    if (el.__err) { el.__err.remove(); el.__err = null; }
    var host = el.closest('[data-field]') || el;
    if (host.style.borderColor === 'rgb(176, 113, 102)') host.style.borderColor = '';
    el.removeAttribute('aria-invalid');
  }
  function note(after, msg, id) {
    var old = id && document.getElementById(id); if (old) old.remove();
    var d = document.createElement('div');
    if (id) d.id = id;
    d.setAttribute('role', 'status');
    d.style.cssText = "font:400 13.5px/1.45 'Helvetica Neue',Helvetica,Arial,sans-serif;color:rgba(0,0,0,.8);margin-top:12px";
    d.textContent = msg;
    after.insertAdjacentElement('afterend', d);
    return d;
  }

  /* ---------- keyboard-only focus ring is CSS; pills ---------- */
  $$('[data-pills]').forEach(function (group) {
    var single = group.getAttribute('data-pills') === 'single';
    var pills = $$('[data-pill]', group);
    function set(p, on) {
      p.setAttribute('style', p.getAttribute(on ? 'data-s-on' : 'data-s-off'));
      p.setAttribute('data-on', on ? '1' : '0');
      p.setAttribute('aria-pressed', on ? 'true' : 'false');
    }
    pills.forEach(function (p) {
      function act() {
        if (single) { pills.forEach(function (q) { set(q, q === p); }); }
        else set(p, p.getAttribute('data-on') !== '1');
        group.dispatchEvent(new CustomEvent('pillchange', { bubbles: true, detail: p }));
      }
      p.addEventListener('click', act); onKey(p, act);
    });
  });

  /* ---------- switches ---------- */
  $$('[data-switch]').forEach(function (sw) {
    function act() {
      var on = sw.getAttribute('aria-checked') !== 'true';
      sw.setAttribute('aria-checked', on ? 'true' : 'false');
      sw.style.background = on ? '#0058CE' : 'rgba(0,0,0,.25)';
      var k = sw.firstElementChild;
      k.style.right = on ? '3px' : 'auto'; k.style.left = on ? 'auto' : '3px';
    }
    sw.addEventListener('click', act); onKey(sw, act);
  });

  /* ---------- radio / check rows ---------- */
  function paintRadio(row, on) {
    var r = $('[data-radio]', row);
    row.setAttribute('aria-checked', on ? 'true' : 'false');
    r.style.background = on ? '#0058CE' : '';
    r.style.border = on ? '5px solid #FFFFFF' : '1px solid rgba(0,0,0,.3)';
    r.style.boxShadow = on ? '0 0 0 1px #0058CE' : 'none';
  }
  $$('[data-opt]').forEach(function (row) {
    var group = row.parentElement, multi = group.getAttribute('data-optgroup') === 'multi';
    var rows = $$(':scope > [data-opt]', group);
    var onR = rows.filter(function (r) { return r.getAttribute('aria-checked') === 'true'; })[0];
    var offR = rows.filter(function (r) { return r.getAttribute('aria-checked') !== 'true'; })[0];
    if (!multi && onR && offR && !group.__styles) group.__styles = { on: onR.getAttribute('style'), off: offR.getAttribute('style') };
    function act() {
      if (multi) paintRadio(row, row.getAttribute('aria-checked') !== 'true');
      else rows.forEach(function (r) {
        paintRadio(r, r === row);
        if (group.__styles) r.setAttribute('style', r === row ? group.__styles.on : group.__styles.off);
      });
    }
    row.addEventListener('click', act); onKey(row, act);
  });

  /* ---------- rating segments ---------- */
  $$('[data-seg]').forEach(function (g) {
    var segs = $$('[data-v]', g);
    function paint(n) { segs.forEach(function (s, i) { s.style.background = i < n ? '#0058CE' : 'rgba(0,0,0,.14)'; s.setAttribute('aria-checked', i + 1 === n ? 'true' : 'false'); }); }
    segs.forEach(function (s) {
      var n = +s.getAttribute('data-v');
      s.addEventListener('click', function () { paint(n); }); onKey(s, function () { paint(n); });
    });
  });

  /* ---------- saved hearts ---------- */
  var saved = store('saved') || [];
  $$('[data-heart]').forEach(function (h) {
    var id = 'listing-paris';
    function paint(on) { h.textContent = on ? '♥' : '♡'; h.setAttribute('aria-pressed', on ? 'true' : 'false'); h.style.color = on ? '#0058CE' : ''; }
    paint(saved.indexOf(id) > -1);
    function act() {
      var i = saved.indexOf(id);
      if (i > -1) saved.splice(i, 1); else saved.push(id);
      store('saved', saved); paint(i === -1);
    }
    h.addEventListener('click', act); onKey(h, act);
  });
  if (PAGE === 'saved' && saved.length) {
    var panel = $('.page > div:last-child');
    if (panel) {
      panel.innerHTML = '<div style="font:600 10px/1 \'Helvetica Neue\',Helvetica,Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:rgba(0,0,0,.7);margin-bottom:16px">Saved · ' + saved.length + '</div>' +
        '<h1 style="margin:0 0 24px;font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif;font-size:44px;line-height:1.02;color:#000000;font-weight:500;letter-spacing:-.035em">Saved spaces</h1>' +
        '<a href="listing.html" style="display:block;text-decoration:none;color:inherit"><div style="height:250px;border-radius:16px;overflow:hidden;margin-bottom:14px"><img src="assets/img/placeholder-street-blue-corner.webp" alt="Independent Store, Le Marais" style="display:block;width:100%;height:100%;object-fit:cover"></div>' +
        '<div style="display:flex;justify-content:space-between;align-items:baseline"><div style="font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif;font-size:27px;line-height:1;font-weight:500;letter-spacing:-.035em">Independent Store — Paris</div><div style="font:600 12px/1 \'Helvetica Neue\',Helvetica,Arial,sans-serif;color:#0058CE;background:#F2F2F0;padding:6px 11px;border-radius:999px">12 cr/day</div></div>' +
        '<div style="font:400 14px/1.5 \'Helvetica Neue\',Helvetica,Arial,sans-serif;color:rgba(0,0,0,.78);margin-top:8px">Le Marais, Paris · 48 m²<br>Free 8–22 Sep</div></a>';
    }
  }

  /* ---------- calendars ---------- */
  var RATE = 12, BALANCE = 248;
  function cellPaint(c, st, variant) {
    c.setAttribute('data-st', st);
    var bg, fg;
    if (variant === 'edit') { bg = st === 'avail' ? '#0058CE' : '#FFFFFF'; fg = st === 'avail' ? '#FFFFFF' : 'rgba(0,0,0,.78)'; }
    else { bg = st === 'picked' ? '#0058CE' : st === 'free' ? '#F2F2F0' : 'rgba(0,0,0,.07)'; fg = st === 'picked' ? '#FFFFFF' : 'rgba(0,0,0,.78)'; }
    c.style.background = bg; c.style.color = fg;
    if (variant === 'edit') c.setAttribute('aria-pressed', st === 'avail' ? 'true' : 'false');
    if (variant === 'pick') c.setAttribute('aria-pressed', st === 'picked' ? 'true' : 'false');
  }
  function cellAt(grid, e) {
    var t = document.elementFromPoint(e.clientX, e.clientY);
    t = t && t.closest('[data-d]');
    return t && grid.contains(t) && +t.getAttribute('data-d') > 0 ? t : null;
  }
  $$('[data-cal="edit"]').forEach(function (grid) {
    var cells = $$('[data-d]', grid).filter(function (c) { return +c.getAttribute('data-d') > 0; });
    cells.forEach(function (c) { c.style.cursor = 'pointer'; c.style.userSelect = 'none'; c.setAttribute('role', 'button'); c.setAttribute('tabindex', '0'); c.setAttribute('aria-label', 'September ' + c.textContent); });
    var root = grid.closest('.vp-desk, .vp-phone') || document.body;
    function summary() {
      var n = cells.filter(function (c) { return c.getAttribute('data-st') === 'avail'; }).length;
      textNodes(root, /\d+ days? marked/, function () { return n + (n === 1 ? ' day' : ' days') + ' marked'; });
      textNodes(root, /^\d+ days? hosted/, function () { return n + (n === 1 ? ' day' : ' days') + ' hosted'; });
      textNodes(root, /= \d+ credits earned/, function () { return '= ' + (n * RATE) + ' credits earned'; });
      store('avail', cells.filter(function (c) { return c.getAttribute('data-st') === 'avail'; }).map(function (c) { return +c.getAttribute('data-d'); }));
    }
    var start = null, mode = 'set', dragging = false, base = null;
    function apply(a, b) {
      var lo = Math.min(a, b), hi = Math.max(a, b);
      cells.forEach(function (c) {
        var d = +c.getAttribute('data-d'), st = base[d];
        if (d >= lo && d <= hi) st = mode === 'set' ? 'avail' : 'empty';
        cellPaint(c, st, 'edit');
      });
    }
    grid.addEventListener('pointerdown', function (e) {
      var c = cellAt(grid, e); if (!c) return;
      start = +c.getAttribute('data-d'); dragging = true;
      mode = c.getAttribute('data-st') === 'avail' ? 'clear' : 'set';
      base = {}; cells.forEach(function (x) { base[+x.getAttribute('data-d')] = x.getAttribute('data-st'); });
      apply(start, start);
    });
    grid.addEventListener('pointermove', function (e) {
      if (!dragging) return; var c = cellAt(grid, e); if (c) apply(start, +c.getAttribute('data-d'));
    });
    window.addEventListener('pointerup', function () { if (dragging) { dragging = false; summary(); } });
    cells.forEach(function (c) {
      onKey(c, function () {
        cellPaint(c, c.getAttribute('data-st') === 'avail' ? 'empty' : 'avail', 'edit'); summary();
      });
    });
    var saved = store('avail');
    if (saved) { cells.forEach(function (c) { cellPaint(c, saved.indexOf(+c.getAttribute('data-d')) > -1 ? 'avail' : 'empty', 'edit'); }); }
    summary();
  });

  $$('[data-cal="pick"]').forEach(function (grid) {
    var cells = $$('[data-d]', grid).filter(function (c) { return +c.getAttribute('data-d') > 0; });
    var root = grid.closest('.vp-desk, .vp-phone') || document.body;
    var state = {}; var range = [10, 17], pending = null, dragging = false;
    cells.forEach(function (c) {
      var d = +c.getAttribute('data-d'), free = d >= 8 && d <= 22;
      c.setAttribute('data-free', free ? '1' : '0');
      if (free) { c.style.cursor = 'pointer'; c.setAttribute('role', 'button'); c.setAttribute('tabindex', '0'); c.setAttribute('aria-label', 'September ' + d); }
      else c.setAttribute('aria-disabled', 'true');
      c.style.userSelect = 'none';
    });
    function paint() {
      cells.forEach(function (c) {
        var d = +c.getAttribute('data-d'), free = c.getAttribute('data-free') === '1';
        cellPaint(c, !free ? 'off' : (range && d >= range[0] && d <= range[1]) ? 'picked' : 'free', 'pick');
      });
      var n = range ? range[1] - range[0] + 1 : 0, total = n * RATE;
      textNodes(root, /\d+ – \d+ Sep selected|Select your dates/, function () { return range ? range[0] + ' – ' + range[1] + ' Sep selected' : 'Select your dates'; });
      textNodes(root, /^\d+ days?\s*$/, function () { return n + (n === 1 ? ' day' : ' days') + ' '; });
      $$('span', root).forEach(function (s) {
        if (/^\d+ credits$/.test(s.textContent.trim()) && s.parentElement.textContent.indexOf('Total') === 0) s.textContent = total + ' credits';
        if (/^\d+ left$/.test(s.textContent.trim())) s.textContent = (BALANCE - total) + ' left';
      });
      store('pick', range);
    }
    function begin(d) {
      if (pending !== null) { range = [Math.min(pending, d), Math.max(pending, d)]; pending = null; }
      else { pending = d; range = [d, d]; }
      paint();
    }
    var dragStart = null;
    grid.addEventListener('pointerdown', function (e) {
      var c = cellAt(grid, e); if (!c || c.getAttribute('data-free') !== '1') return;
      dragStart = +c.getAttribute('data-d'); dragging = false;
    });
    grid.addEventListener('pointermove', function (e) {
      if (dragStart === null) return; var c = cellAt(grid, e);
      if (c && c.getAttribute('data-free') === '1' && +c.getAttribute('data-d') !== dragStart) {
        dragging = true; pending = null; var d = +c.getAttribute('data-d'); range = [Math.min(dragStart, d), Math.max(dragStart, d)]; paint();
      }
    });
    window.addEventListener('pointerup', function (e) {
      if (dragStart === null) return;
      var s = dragStart; dragStart = null;
      if (!dragging) { var c = cellAt(grid, e); if (c && c.getAttribute('data-free') === '1') begin(s); }
      dragging = false;
    });
    cells.forEach(function (c) { onKey(c, function () { if (c.getAttribute('data-free') === '1') begin(+c.getAttribute('data-d')); }); });
    paint();
  });

  /* ---------- fields ---------- */
  $$('[data-act]').forEach(function (b) {
    var input = $('input', b.parentElement);
    b.addEventListener('click', function () {
      if (b.getAttribute('data-act') === 'show') {
        var hid = input.type === 'password'; input.type = hid ? 'text' : 'password';
        b.textContent = hid ? 'Hide' : 'Show';
      } else { input.focus(); input.select(); }
    });
  });
  $$('.fld').forEach(function (f) { f.addEventListener('input', function () { clearError(f); }); });
  $$('[data-field]').forEach(function (h) {
    h.addEventListener('focusin', function () { h.style.borderColor = 'rgba(0,88,206,.7)'; });
    h.addEventListener('focusout', function () { h.style.borderColor = ''; });
  });

  /* ---------- gated navigation with inline validation ---------- */
  function guard(label, test) {
    $$('a.btn').forEach(function (a) {
      if (a.textContent.trim() !== label) return;
      a.addEventListener('click', function (e) {
        var root = a.closest('.vp-desk, .vp-phone') || document.body;
        var ok = test(root);
        if (ok === false) { e.preventDefault(); var er = $('[aria-invalid=true]', root) || $('.err', root); if (er && er.scrollIntoView) er.scrollIntoView({ block: 'center' }); }
      });
    });
  }
  function need(root, label, msg, rx) {
    var f = $$('.fld', root).filter(function (x) { return (x.getAttribute('aria-label') || '').toLowerCase().indexOf(label) === 0; })[0];
    if (!f) return true;
    var v = f.value.trim();
    if (!v || (rx && !rx.test(v))) { errorFor(f, msg); return false; }
    return true;
  }
  guard('Sign in', function (root) {
    var a = need(root, 'email', 'Enter the email address you joined with, for example name@studio.com.', /^\S+@\S+\.\S+$/);
    var b = need(root, 'password', 'Enter your password, or ask us to email you a sign-in link instead.');
    return a && b;
  });
  guard('Continue to the space', function (root) {
    var r = [need(root, 'street address', 'We need the street address of the space so we can match it to your business register entry.'),
      need(root, 'postcode', 'Add the postcode so we can place the neighbourhood circle.'),
      need(root, 'city', 'Add the city this space is in.')];
    return r.every(Boolean);
  });
  guard('Continue to photos', function (root) { return need(root, 'name your listing', 'Give the listing a name members will recognise, for example “Independent Store — Paris”.'); });
  guard('Send request', function (root) {
    var picked = $$('[data-st=picked]', root).length;
    if (!picked) {
      var g = $('[data-cal=pick]', root); var n = $('.err', g.parentElement);
      if (!n) { var d = note(g, 'Choose dates inside the host’s open range, 8–22 September.'); d.className = 'err'; d.style.color = 'rgba(0,0,0,.8)'; }
      return false;
    }
    store('request', { range: store('pick') });
  });
  guard('Publish listing', function (root) {
    var n = (store('photos') || 7);
    if (n < 4) { var b = $$('a.btn', root).filter(function (x) { return x.textContent.trim() === 'Publish listing'; })[0]; note(b, 'A listing needs at least 4 photos, including a cover, before it can go live.', 'pub-err'); return false; }
  });

  /* "Email me a sign-in link", "Save draft", notify buttons — buttons without destinations */
  $$('button').forEach(function (b) {
    var t = b.textContent.trim();
    if (t === 'Email me a sign-in link') b.addEventListener('click', function () {
      var root = b.closest('.vp-desk, .vp-phone') || document.body, em = $('input[type=email]', root);
      if (em && !/^\S+@\S+\.\S+$/.test(em.value.trim())) { errorFor(em, 'Enter your email address and we will send the link there.'); return; }
      note(b, 'Link sent to ' + (em ? em.value.trim() : 'your email') + '. It works once and expires in 15 minutes.', 'magic-note');
    });
    if (t === 'Save draft') b.addEventListener('click', function () {
      store('draftSavedAt', Date.now()); var old = b.textContent; b.textContent = 'Draft saved'; setTimeout(function () { b.textContent = old; }, 2200);
    });
    if (t === 'Tell me when Porto opens') {
      if (store('notify-porto')) b.textContent = 'We will tell you ✓';
      b.addEventListener('click', function () { var on = !store('notify-porto'); store('notify-porto', on); b.textContent = on ? 'We will tell you ✓' : 'Tell me when Porto opens'; });
    }
    if (t === 'View agreement' || t === 'Read the agreement' || t === 'Contact support' || t === 'Counter dates' || t === 'Decline' || t === 'Close my account' || t === 'Pause my listing' || t === 'Preview listing') { /* handled below */ }
  });

  /* Host inbox actions: inline, never a modal */
  $$('button').forEach(function (b) {
    var t = b.textContent.trim(), msg = {
      'Decline': 'Declined. Their held credits return to them immediately, and they can send a new request for other dates.',
      'Counter dates': 'Counter-offer started. Choose the dates that work for you and add a short note before it goes back to them.',
      'View agreement': 'The agreement covers dates, condition, liability and cancellation. It is generated when both sides accept.',
      'Read the agreement': 'The agreement covers dates, condition, liability and cancellation. It is generated when both sides accept.',
      'Contact support': 'Support replies within one working day. Include the exchange and what happened.',
      'Pause my listing': 'Paused. Your listing is hidden and existing confirmed exchanges are unaffected. Your credits stay as they are.',
      'Close my account': 'Closing removes your listing and profile. Your credits cannot be cashed out and are lost on closing; pausing keeps them.'
    }[t];
    if (!msg) return;
    b.addEventListener('click', function () {
      var host = b.parentElement, id = 'n-' + t.replace(/\W/g, '');
      note(host, msg, id);
    });
  });

  /* ---------- messages / thread ---------- */
  $$('[data-send]').forEach(function (b) {
    var root = b.closest('.vp-desk, .vp-phone') || document.body;
    var input = $('.composer', b.parentElement) || $('.composer', root);
    var mine = $$('[style*="14px 14px 4px 14px"]', root).pop();
    var thread = mine && mine.parentElement;
    function send() {
      var v = input && input.value.trim(); if (!v) { if (input) input.focus(); return; }
      if (thread && mine) {
        var m = mine.cloneNode(false); m.textContent = v; thread.appendChild(m);
        thread.scrollTop = thread.scrollHeight;
      }
      input.value = '';
    }
    b.addEventListener('click', send);
    if (input) input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); send(); } });
  });

  /* ---------- ledger filters ---------- */
  var ledger = $$('[data-kind]');
  if (ledger.length) {
    var g = $('[data-pills=single]');
    if (g) g.addEventListener('pillchange', function (e) {
      var f = e.detail.textContent.trim().toLowerCase();
      ledger.forEach(function (r) {
        var k = r.getAttribute('data-kind');
        var show = f === 'everything' || f === k;
        r.style.display = show ? '' : 'none';
      });
    });
  }

  /* ---------- explore: space-type quick toggles keep summary in sync ---------- */
  var types = $('[data-pills=multi]');
  if (PAGE === 'explore' && types) {
    types.addEventListener('pillchange', function () {
      var on = $$('[data-pill][data-on="1"]', document.body).length;
    });
  }


  /* ---------- phone Explore: the summary card opens a full search panel ---------- */
  (function () {
    if (PAGE !== 'explore') return;
    var phone = $('.vp-phone'); if (!phone) return;
    var card = $$('div', phone).filter(function (d) { return /border-radius:999px/.test(d.getAttribute('style') || '') && /Edit$/.test(d.textContent.trim()) && /Paris · Shop/.test(d.textContent); })[0];
    if (!card) return;
    var qs = new URLSearchParams(location.search);
    var glyph = card.firstElementChild; if (glyph && glyph.tagName === 'A') { var sp = document.createElement('span'); sp.setAttribute('style', glyph.getAttribute('style')); sp.textContent = glyph.textContent; glyph.replaceWith(sp); }
    var lines = card.querySelectorAll('div > div');
    if (qs.get('city')) {
      var ty = qs.get('type') || 'Shop';
      if (lines[0]) lines[0].textContent = qs.get('city') + ' · ' + ty;
    }
    var panel = document.createElement('div'); panel.hidden = true; panel.id = 'm-search';
    panel.setAttribute('style', 'margin:0 20px 14px;background:#FFFFFF;border:1px solid rgba(0,0,0,.16);border-radius:20px;overflow:hidden');
    var lab = 'font:600 10px/1 \'Helvetica Neue\',Helvetica,Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:rgba(0,0,0,.7);margin-bottom:7px';
    var val = 'font:400 17px/1 \'Helvetica Neue\',Helvetica,Arial,sans-serif;color:#000000';
    panel.innerHTML = '<div style="padding:16px 20px;border-bottom:1px solid rgba(0,0,0,.1)"><div style="' + lab + '">Where do you want to go?</div><div style="' + val + '">Paris</div></div>' +
      '<div style="display:flex"><div style="flex:1;padding:16px 20px;border-right:1px solid rgba(0,0,0,.1)"><div style="' + lab + '">Dates</div><div style="' + val.replace('17px', '16px') + '">8–22 Sep</div></div>' +
      '<div style="flex:1;padding:16px 20px"><div style="' + lab + '">Type</div><div style="' + val.replace('17px', '16px') + '">Shop</div></div></div>' +
      '<a class="btn" href="explore.html" style="border:0;background:#FF3C00;color:#000000;padding:16px;font:600 13px/1 \'Helvetica Neue\',Helvetica,Arial,sans-serif;width:100%">Search</a>';
    var wrap = card.parentElement; wrap.insertAdjacentElement('afterend', panel);
    card.setAttribute('role', 'button'); card.setAttribute('tabindex', '0'); card.setAttribute('aria-expanded', 'false'); card.setAttribute('aria-controls', 'm-search'); card.style.cursor = 'pointer';
    function toggle() { panel.hidden = !panel.hidden; card.setAttribute('aria-expanded', panel.hidden ? 'false' : 'true'); var e = $$('span', card).filter(function (x) { return /^(Edit|Close)$/.test(x.textContent.trim()); })[0]; if (e) e.textContent = panel.hidden ? 'Edit' : 'Close'; if (!panel.hidden) { var i = $('input', panel); if (i) i.focus(); } }
    card.addEventListener('click', toggle); onKey(card, toggle);
    if (!qs.get('city')) { /* keep closed until asked */ }
  })();

  /* ---------- search bars: city suggestions, date-range picker, space type ---------- */
  (function () {
    var CITIES = [['Paris', 18], ['Barcelona', 8], ['Milan', 6], ['Madrid', 5], ['Lisbon', 5], ['Berlin', 5], ['Copenhagen', 4], ['Athens', 4], ['Amsterdam', 3], ['Brussels', 2], ['Porto', 2]];
    var TYPES = ['Shop or studio', 'Shop', 'Studio'];
    var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var MONL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var qs = new URLSearchParams(location.search);
    var pop = null, owner = null;

    function day(y, m, d) { return new Date(y, m, d); }
    function iso(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
    function parse(v) { var m = /^(\d{4})-(\d\d)-(\d\d)$/.exec(v || ''); return m ? day(+m[1], +m[2] - 1, +m[3]) : null; }
    function fmt(a, b) {
      if (!a) return '';
      if (!b || +a === +b) return a.getDate() + ' ' + MON[a.getMonth()];
      if (a.getMonth() === b.getMonth()) return a.getDate() + '–' + b.getDate() + ' ' + MON[a.getMonth()];
      return a.getDate() + ' ' + MON[a.getMonth()] + ' – ' + b.getDate() + ' ' + MON[b.getMonth()];
    }
    function close() { if (pop) { pop.remove(); pop = null; if (owner) owner.setAttribute('aria-expanded', 'false'); owner = null; } }
    function open(anchor, cls) {
      close();
      pop = document.createElement('div'); pop.className = 'ss-pop ' + (cls || ''); document.body.appendChild(pop);
      owner = anchor; anchor.setAttribute('aria-expanded', 'true');
      return pop;
    }
    function place(anchor) {
      var r = anchor.getBoundingClientRect(), w = pop.offsetWidth;
      var left = Math.min(Math.max(16, r.left + window.scrollX), window.scrollX + document.documentElement.clientWidth - w - 16);
      pop.style.left = left + 'px'; pop.style.top = (r.bottom + window.scrollY + 8) + 'px';
    }
    document.addEventListener('pointerdown', function (e) { if (pop && !pop.contains(e.target) && !(owner && owner.contains(e.target))) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && pop) { var o = owner; close(); if (o) o.focus(); } });

    function bars() {
      var found = [], root = document.body;
      // labelled cells (home)
      $$('div', root).forEach(function (l) {
        if (l.children.length || l.textContent.trim() !== 'Where do you want to go?') return;
        var cell = l.parentElement, vals = {};
        var bar = cell.parentElement;
        // gather sibling cells by label text within the same search block
        var scope = bar.parentElement && bar.querySelector('[style*="Dates"]') ? bar : bar;
        var cells = $$('div', bar.closest('div[style*="border-radius"]') || bar).filter(function (d) { return !d.children.length && /^(Dates|Space type|Type)$/.test(d.textContent.trim()); });
        var b = { city: l.nextElementSibling, dates: null, type: null, host: bar };
        cells.forEach(function (c) { if (c.textContent.trim() === 'Dates') b.dates = c.nextElementSibling; else b.type = c.nextElementSibling; });
        var wrap = cell.closest('[style*="border-radius"]');
        b.search = wrap && $$('a.btn', wrap)[0] || (wrap && wrap.parentElement && $$('a.btn', wrap.parentElement).filter(function (x) { return x.textContent.trim() === 'Search'; })[0]);
        if (!b.search) b.search = $$('a.btn', root).filter(function (x) { return x.textContent.trim() === 'Search' && wrap.contains(x); })[0];
        found.push(b);
      });
      // unlabelled pill (explore + empty states)
      $$('[data-nav-mid]').forEach(function (m) {
        var k = $$(':scope > *', m);
        if (k.length === 4 && /^Search$/.test(k[3].textContent.trim())) found.push({ city: k[0], dates: k[1], type: k[2], search: k[3], pill: true });
      });
      return found;
    }

    bars().forEach(function (b) {
      var emptyDates = b.dates && /Add dates/i.test(b.dates.textContent);
      var st = { city: b.city.textContent.trim(), from: null, to: null, type: b.type.textContent.trim() };
      var m = /^(\d+)\s*[–-]\s*(\d+) Sep/.exec(b.dates.textContent.trim());
      if (m) { st.from = day(2026, 8, +m[1]); st.to = day(2026, 8, +m[2]); }
      if (qs.get('city')) st.city = qs.get('city');
      if (qs.get('from')) { st.from = parse(qs.get('from')); st.to = parse(qs.get('to')); }
      if (qs.get('type') && TYPES.indexOf(qs.get('type')) > -1) st.type = qs.get('type');
      var dateColor = b.dates.style.color || '';

      /* city: a real input */
      var cs = getComputedStyle(b.city);
      var inp = document.createElement('input'); inp.type = 'text'; inp.value = st.city; inp.placeholder = st.city || 'Where to?'; inp.autocomplete = 'off';
      inp.setAttribute('role', 'combobox'); inp.setAttribute('aria-label', 'City'); inp.setAttribute('aria-expanded', 'false'); inp.setAttribute('aria-autocomplete', 'list');
      inp.className = 'ss-in'; inp.style.cssText = 'font:' + cs.font + ';color:' + cs.color + ';background:transparent;border:0;padding:0;margin:0;width:100%;min-width:0;outline:0;letter-spacing:inherit';
      b.city.textContent = ''; b.city.appendChild(inp);
      var cityCell = b.pill ? b.city : b.city.parentElement;
      cityCell.style.cursor = 'text';
      cityCell.addEventListener('click', function () { inp.focus(); });

      var typed = false;
      function cityList() {
        var q = typed ? inp.value.trim().toLowerCase() : '';
        var list = CITIES.filter(function (c) { return !q || c[0].toLowerCase().indexOf(q) === 0; });
        var p = open(inp, 'ss-list'); p.setAttribute('role', 'listbox');
        if (!list.length) { p.innerHTML = '<div class="ss-none">No spaces listed in “' + inp.value.replace(/[<>&]/g, '') + '” yet. Search anyway and we will tell you when it opens.</div>'; place(cityCell); return; }
        list.forEach(function (c, i) {
          var o = document.createElement('div'); o.className = 'ss-opt'; o.setAttribute('role', 'option'); o.tabIndex = -1;
          o.innerHTML = '<span>' + c[0] + '</span><small>' + (c[1] >= 4 ? c[1] + ' spaces' : 'Not open yet') + '</small>';
          o.addEventListener('pointerdown', function (e) { e.preventDefault(); });
          o.addEventListener('click', function () { st.city = c[0]; inp.value = c[0]; close(); if (b.dates && !b.pill) openDates(); });
          p.appendChild(o);
        });
        place(cityCell);
      }
      inp.addEventListener('focus', function () { typed = false; inp.select(); cityList(); });
      inp.addEventListener('input', function () { typed = true; st.city = inp.value; inp.placeholder = ''; cityList(); });
      inp.addEventListener('keydown', function (e) {
        var opts = pop ? $$('.ss-opt', pop) : [], cur = opts.indexOf(document.activeElement);
        if (e.key === 'ArrowDown' && opts.length) { e.preventDefault(); opts[Math.min(opts.length - 1, cur + 1)].focus(); }
        if (e.key === 'Enter') { e.preventDefault(); var q = inp.value.trim().toLowerCase(); var hit = CITIES.filter(function (c) { return c[0].toLowerCase().indexOf(q) === 0; })[0]; if (hit && q) { inp.value = st.city = hit[0]; } close(); go(); }
      });
      document.addEventListener('keydown', function (e) {
        if (!pop || !pop.classList.contains('ss-list') || owner !== inp) return;
        var opts = $$('.ss-opt', pop), i = opts.indexOf(document.activeElement);
        if (i < 0) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); opts[Math.min(opts.length - 1, i + 1)].focus(); }
        if (e.key === 'ArrowUp') { e.preventDefault(); (i ? opts[i - 1] : inp).focus(); }
        if (e.key === 'Enter') { e.preventDefault(); opts[i].click(); }
      });

      /* dates: range picker */
      var view = st.from ? new Date(st.from.getFullYear(), st.from.getMonth(), 1) : new Date(2026, 8, 1);
      var dcell = b.pill ? b.dates : b.dates.parentElement;
      function paintDates() {
        var t = fmt(st.from, st.to);
        b.dates.textContent = t || 'Add dates';
        if (!b.pill) b.dates.style.color = t ? '#000000' : dateColor;
      }
      function paintRange(hover) {
        if (!pop) return;
        var a = st.from, z = st.to || (a && hover && hover > a ? hover : null);
        $$('.ss-day', pop).forEach(function (btn) {
          var dt = parse(btn.dataset.d), end = (a && +dt === +a) || (z && +dt === +z), mid = !end && a && z && dt > a && dt < z;
          btn.classList.toggle('is-end', !!end); btn.classList.toggle('is-mid', !!mid); btn.setAttribute('aria-pressed', end ? 'true' : 'false');
        });
        var sum = $('.ss-sum', pop); if (sum) sum.textContent = fmt(st.from, st.to) || 'Choose arrival and departure';
      }
      function drawCal(hover) {
        var months = document.documentElement.clientWidth >= 720 ? 2 : 1, h = '';
        h += '<div class="ss-cal-head"><button type="button" class="ss-nav" data-n="-1" aria-label="Previous month">‹</button><span class="ss-sp"></span><button type="button" class="ss-nav" data-n="1" aria-label="Next month">›</button></div><div class="ss-months">';
        for (var k = 0; k < months; k++) {
          var first = new Date(view.getFullYear(), view.getMonth() + k, 1), lead = (first.getDay() + 6) % 7, n = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
          h += '<div class="ss-month"><div class="ss-mt">' + MONL[first.getMonth()] + ' ' + first.getFullYear() + '</div><div class="ss-grid">';
          'MTWTFSS'.split('').forEach(function (w) { h += '<span class="ss-wd">' + w + '</span>'; });
          for (var i = 0; i < lead; i++) h += '<span></span>';
          for (var d = 1; d <= n; d++) {
            var dt = new Date(first.getFullYear(), first.getMonth(), d), a = st.from, z = st.to || (a && !st.to && hover && hover > a ? hover : null);
            var cls = 'ss-day';
            if (a && +dt === +a) cls += ' is-end'; if (z && +dt === +z) cls += ' is-end'; else if (a && z && dt > a && dt < z) cls += ' is-mid';
            h += '<button type="button" class="' + cls + '" data-d="' + iso(dt) + '" aria-pressed="' + (cls.indexOf('is-end') > -1) + '" aria-label="' + d + ' ' + MONL[dt.getMonth()] + '">' + d + '</button>';
          }
          h += '</div></div>';
        }
        h += '</div><div class="ss-foot"><button type="button" class="ss-clear">Clear</button><span class="ss-sum">' + (fmt(st.from, st.to) || 'Choose arrival and departure') + '</span><button type="button" class="ss-done">Done</button></div>';
        pop.innerHTML = h;
        var head = pop.querySelector('.ss-sp'); head.textContent = '';
        place(dcell);
      }
      function openDates() {
        var p = open(dcell, 'ss-dates'); p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Choose dates');
        drawCal(null);
        p.addEventListener('click', function (e) {
          var t = e.target.closest('button'); if (!t) return;
          if (t.classList.contains('ss-nav')) { view = new Date(view.getFullYear(), view.getMonth() + (+t.dataset.n), 1); drawCal(null); return; }
          if (t.classList.contains('ss-clear')) { st.from = st.to = null; paintDates(); paintRange(null); return; }
          if (t.classList.contains('ss-done')) { close(); dcell.focus(); return; }
          if (t.dataset.d) {
            var d = parse(t.dataset.d);
            if (!st.from || st.to) { st.from = d; st.to = null; }
            else if (d < st.from) { st.from = d; }
            else { st.to = d; }
            paintDates(); paintRange(null);
          }
        });
        p.addEventListener('mouseover', function (e) {
          var t = e.target.closest('[data-d]'); if (t && st.from && !st.to) paintRange(parse(t.dataset.d));
        });
      }
      dcell.setAttribute('role', 'button'); dcell.setAttribute('tabindex', '0'); dcell.setAttribute('aria-haspopup', 'dialog'); dcell.setAttribute('aria-expanded', 'false'); dcell.style.cursor = 'pointer';
      dcell.addEventListener('click', function () { if (pop && owner === dcell) close(); else openDates(); });
      onKey(dcell, function () { if (pop && owner === dcell) close(); else openDates(); });
      paintDates();

      /* space type */
      var tcell = b.pill ? b.type : b.type.parentElement;
      function paintType() { b.type.textContent = st.type; if (!b.pill) b.type.style.color = '#000000'; }
      function openType() {
        var p = open(tcell, 'ss-list'); p.setAttribute('role', 'listbox');
        TYPES.forEach(function (t) {
          var o = document.createElement('div'); o.className = 'ss-opt'; o.setAttribute('role', 'option'); o.tabIndex = 0; o.setAttribute('aria-selected', t === st.type ? 'true' : 'false'); o.textContent = t;
          function pick() { st.type = t; paintType(); close(); tcell.focus(); }
          o.addEventListener('click', pick); onKey(o, pick); p.appendChild(o);
        });
        place(tcell);
      }
      tcell.setAttribute('role', 'button'); tcell.setAttribute('tabindex', '0'); tcell.setAttribute('aria-haspopup', 'listbox'); tcell.setAttribute('aria-expanded', 'false'); tcell.style.cursor = 'pointer';
      tcell.addEventListener('click', function () { if (pop && owner === tcell) close(); else openType(); });
      onKey(tcell, function () { if (pop && owner === tcell) close(); else openType(); });
      paintType();

      /* go */
      function go() {
        var c = st.city.trim();
        if (!c) { inp.placeholder = 'Choose a city'; inp.focus(); return; }
        var known = CITIES.filter(function (x) { return x[0].toLowerCase() === c.toLowerCase(); })[0];
        var name = known ? known[0] : c.replace(/\b\w/g, function (x) { return x.toUpperCase(); });
        var p = new URLSearchParams(); p.set('city', name);
        if (st.from) p.set('from', iso(st.from)); if (st.to) p.set('to', iso(st.to));
        p.set('type', st.type);
        location.href = (known && known[0] === 'Paris' && known[1] >= 4 ? 'explore.html' : 'explore-empty.html') + '?' + p.toString();
      }
      if (b.search) b.search.addEventListener('click', function (e) { e.preventDefault(); close(); go(); });
    });

    /* explore-empty: carry the searched city into the copy */
    if (PAGE === 'explore-empty' && qs.get('city') && qs.get('city') !== 'Porto') {
      var city = qs.get('city');
      textNodes(document.body, /Porto/g, function () { return city; });
    }
  })();

  /* ---------- map view toggle on explore ---------- */
  $$('iframe').forEach(function (f) {
    var box = f.parentElement, bar = box.previousElementSibling;
    if (!bar) return;
    var tabs = $$('span', bar).filter(function (s) { return /^(Map|List only)$/.test(s.textContent.trim()); });
    if (tabs.length !== 2) return;
    var on = tabs[0].getAttribute('style'), off = tabs[1].getAttribute('style');
    tabs.forEach(function (t, i) {
      t.setAttribute('role', 'button'); t.setAttribute('tabindex', '0'); t.style.cursor = 'pointer';
      function act() {
        tabs.forEach(function (x, j) { x.setAttribute('style', (j === i ? on : off) + ';cursor:pointer'); x.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
        box.style.display = i === 0 ? '' : 'none';
      }
      t.addEventListener('click', act); onKey(t, act);
    });
  });

  /* ---------- photo reordering (list step 3): drag tiles, or move with arrow keys ---------- */
  var grid = $('[data-g=c4]');
  if (PAGE === 'list-3-photos' && grid) {
    var tiles = $$(':scope > div', grid).filter(function (t) { return $('img', t); });
    tiles.forEach(function (t) {
      t.setAttribute('draggable', 'true'); t.setAttribute('tabindex', '0'); t.style.cursor = 'grab';
      t.setAttribute('aria-label', 'Photo. Drag, or press arrow keys, to reorder.');
      t.addEventListener('dragstart', function (e) { t.__drag = true; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', ''); } catch (x) {} grid.__d = t; t.style.opacity = '.5'; });
      t.addEventListener('dragend', function () { t.style.opacity = ''; grid.__d = null; });
      t.addEventListener('dragover', function (e) { if (grid.__d) e.preventDefault(); });
      t.addEventListener('drop', function (e) {
        e.preventDefault(); var d = grid.__d; if (!d || d === t) return;
        var kids = $$(':scope > div', grid), di = kids.indexOf(d), ti = kids.indexOf(t);
        grid.insertBefore(d, di < ti ? t.nextSibling : t);
      });
      t.addEventListener('keydown', function (e) {
        var k = e.key; if (k !== 'ArrowLeft' && k !== 'ArrowRight') return; e.preventDefault();
        var sib = k === 'ArrowLeft' ? t.previousElementSibling : t.nextElementSibling;
        if (sib && $('img', sib)) { grid.insertBefore(t, k === 'ArrowLeft' ? sib : sib.nextSibling); t.focus(); }
      });
    });
  }


  /* ---------- mobile nav for pages without a dedicated phone layout ---------- */
  document.documentElement.classList.add('js');
})();
