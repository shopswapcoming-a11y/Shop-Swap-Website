/* Shop Swap sentence search (v6). Renders into every [data-ss] element.
   data-ss="lg" (home, 52px) or "sm" (explore, 30px). Mode is shared with city pairs via [data-arrow]. */
(function () {
  'use strict';
  var H = "'Helvetica Neue',Helvetica,Arial,sans-serif";
  var ORIGIN = 'Barcelona';
  var CITIES = [['Paris', 18], ['Lisbon', 9], ['Milan', 7], ['Berlin', 11], ['Copenhagen', 5], ['Athens', 4], ['Amsterdam', 6], ['Vienna', 0], ['Prague', 0]];
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var MONL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var TODAY = (function () { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); })();
  function fmt(a, b) {
    if (!a) return '';
    if (!b || +a === +b) return a.getDate() + ' ' + MON[a.getMonth()];
    if (a.getMonth() === b.getMonth()) return a.getDate() + ' – ' + b.getDate() + ' ' + MON[b.getMonth()];
    return a.getDate() + ' ' + MON[a.getMonth()] + ' – ' + b.getDate() + ' ' + MON[b.getMonth()];
  }
  function getRange() { var r = get('range', null); return r ? [new Date(r[0]), new Date(r[1])] : [null, null]; }
  function setRange(a, b) { put('range', [+a, +b]); st.dates = fmt(a, b); put('dates', st.dates); }
  function get(k, d) { try { var v = localStorage.getItem('ss:' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function put(k, v) { try { localStorage.setItem('ss:' + k, JSON.stringify(v)); } catch (e) {} }
  var qs = new URLSearchParams(location.search);
  var st = { mode: get('mode', 'direct'), dest: qs.get('city') || get('dest', ''), dates: get('range', null) ? get('dates', 'Add dates') : 'Add dates' };
  if (document.body.querySelector('[data-ss="sm"]') && !st.dest) st.dest = 'Paris';
  var arrow = function () { return st.mode === 'direct' ? '↔' : '→'; };
  var modeWord = function () { return st.mode === 'direct' ? 'Swap' : 'Visit'; };
  var modeLine = function () { return st.mode === 'direct' ? "Swap: they move into your shop while you're in theirs." : 'Visit: you use their shop with credits, and yours stays as it is.'; };
  var LBL = 'font:600 10px/1 ' + H + ';letter-spacing:.12em;text-transform:uppercase;color:rgba(0,0,0,.55)';
  var POP = 'position:absolute;top:calc(100% + 10px);width:300px;background:#FFFFFF;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.14),0 0 0 1px rgba(0,0,0,.08);padding:8px;display:flex;flex-direction:column;z-index:40';
  var OPT = 'border:0;background:transparent;border-radius:9px;padding:12px 14px;display:flex;justify-content:space-between;align-items:baseline;gap:12px;cursor:pointer;text-align:left;font:500 18px/1 ' + H + ';letter-spacing:-.02em;color:#000000';

  function el(tag, style, html) { var e = document.createElement(tag); if (style) e.setAttribute('style', style); if (html != null) e.innerHTML = html; return e; }
  function field(label, extra) { var f = el('div', 'position:relative;display:flex;flex-direction:column;gap:10px;' + (extra || '')); f.appendChild(el('span', LBL, label)); return f; }

  function paintPairs() {
    document.querySelectorAll('[data-arrow]').forEach(function (a) { a.textContent = arrow(); });
  }

  function render(host) {
    var lg = host.getAttribute('data-ss') !== 'sm';
    var big = lg ? 52 : 30, pillH = lg ? 52 : 38, arr = lg ? 30 : 22, word = lg ? 16 : 14, dsz = lg ? 19 : 15, go = lg ? 66 : 46;
    var BIG = 'font:500 ' + big + 'px/1.05 ' + H + ';letter-spacing:-.045em;white-space:nowrap';
    host.innerHTML = '';
    var bar = el('div', 'display:flex;align-items:flex-start;gap:' + (lg ? 28 : 22) + 'px;flex-wrap:wrap;' + (lg ? 'border-top:1px solid rgba(0,0,0,.14);border-bottom:1px solid rgba(0,0,0,.14);padding:22px 0' : ''));
    var left = el('div', 'flex:0 1 auto;min-width:0;display:flex;align-items:flex-start;gap:22px;flex-wrap:wrap');
    var fFrom = field('From'); fFrom.appendChild(el('span', BIG + ';color:#000000', ORIGIN));
    var fType = field('Type');
    var tBtn = el('button', 'border:0;background:#F2F2F0;border-radius:999px;height:' + pillH + 'px;padding:0 ' + (lg ? 20 : 16) + 'px;display:flex;align-items:center;gap:10px;cursor:pointer;white-space:nowrap');
    tBtn.type = 'button'; tBtn.title = 'Switch between swap and visit';
    tBtn.innerHTML = '<span style="font:500 ' + arr + 'px/1 ' + H + ';color:#000000">' + arrow() + '</span><span style="font:500 ' + word + 'px/1 ' + H + ';color:#000000">' + modeWord() + '</span>';
    tBtn.onmouseenter = function () { tBtn.style.background = '#E6E5E2'; }; tBtn.onmouseleave = function () { tBtn.style.background = '#F2F2F0'; };
    tBtn.onclick = function () { st.mode = st.mode === 'direct' ? 'credits' : 'direct'; put('mode', st.mode); renderAll(); paintPairs(); };
    fType.appendChild(tBtn);
    var fTo = field('To', 'flex:none');
    var toWrap = el('span', 'position:relative;display:inline-block'); fTo.appendChild(toWrap);
    function showDest() {
      toWrap.innerHTML = '';
      var b = el('button', 'border:0;background:none;padding:0;' + BIG + ';color:' + (st.dest ? '#0058CE' : 'rgba(0,0,0,.3)') + ';border-bottom:3px solid #0058CE;cursor:text;display:flex;align-items:center');
      b.type = 'button';
      b.innerHTML = st.dest ? st.dest : '<span style="display:inline-block;width:3px;height:.85em;background:#0058CE;margin-right:6px;animation:ssBlink 1s steps(1) infinite"></span>Where to?';
      b.onclick = editDest; toWrap.appendChild(b);
    }
    function editDest() {
      toWrap.innerHTML = '';
      var inp = el('input', BIG + ';color:#0058CE;border:0;border-bottom:3px solid #0058CE;outline:none;background:transparent;width:7ch;padding:0');
      inp.placeholder = 'Where to?'; inp.value = '';
      var pop = el('div', POP + ';left:0');
      function list() {
        var q = inp.value.trim().toLowerCase(); pop.innerHTML = '';
        var l = CITIES.filter(function (c) { return !q || c[0].toLowerCase().indexOf(q) === 0; });
        if (!l.length) pop.appendChild(el('div', 'padding:12px 14px;font:400 14px/1.4 ' + H + ';color:rgba(0,0,0,.6)', 'No spaces there yet'));
        l.forEach(function (c) {
          var open = c[1] > 0;
          var o = el('button', OPT + ';cursor:' + (open ? 'pointer' : 'default') + ';color:' + (open ? '#000000' : 'rgba(0,0,0,.35)'), c[0] + '<span style="font:400 13px/1 ' + H + ';letter-spacing:0;color:rgba(0,0,0,.6);white-space:nowrap">' + (open ? c[1] + ' spaces' : 'Opening soon') + '</span>');
          o.type = 'button';
          o.onmouseenter = function () { o.style.background = '#F2F2F0'; }; o.onmouseleave = function () { o.style.background = 'transparent'; };
          o.onmousedown = function (e) { e.preventDefault(); if (open) pick(c[0]); };
          pop.appendChild(o);
        });
        return l.filter(function (c) { return c[1] > 0; });
      }
      function pick(c) { st.dest = c; put('dest', c); renderAll(); }
      inp.oninput = list;
      inp.onkeydown = function (e) { if (e.key === 'Enter') { var l = list(); if (l[0]) pick(l[0][0]); } if (e.key === 'Escape') showDest(); };
      inp.onblur = function () { setTimeout(showDest, 120); };
      toWrap.appendChild(inp); toWrap.appendChild(pop); list(); inp.focus();
    }
    showDest();
    left.appendChild(fFrom); left.appendChild(fType); left.appendChild(fTo);
    var fWhen = field('When', '');
    var dBtn = el('button', 'border:0;background:none;padding:6px 0;font:400 ' + dsz + 'px/1.2 ' + H + ';color:#000000;border-bottom:1px solid rgba(0,0,0,.3);cursor:pointer;white-space:nowrap;text-align:left', st.dates);
    dBtn.type = 'button';
    var dPop = null;
    dBtn.onclick = function () {
      if (dPop) { dPop.remove(); dPop = null; return; }
      dPop = el('div', POP + ';left:0;width:auto;padding:16px 18px 14px'); dPop.setAttribute('role', 'dialog'); dPop.setAttribute('aria-label', 'Choose dates');
      var r = getRange(), from = r[0], to = r[1], view = from ? new Date(from.getFullYear(), from.getMonth(), 1) : new Date(TODAY.getFullYear(), TODAY.getMonth(), 1);
      function draw() {
        var months = document.documentElement.clientWidth >= 720 ? 2 : 1, h = '<div class="ss-cal-head"><button type="button" class="ss-nav" data-n="-1" aria-label="Previous month">‹</button><button type="button" class="ss-nav" data-n="1" aria-label="Next month">›</button></div><div class="ss-months">';
        for (var mi = 0; mi < months; mi++) {
          var m0 = new Date(view.getFullYear(), view.getMonth() + mi, 1), days = new Date(m0.getFullYear(), m0.getMonth() + 1, 0).getDate(), lead = (m0.getDay() + 6) % 7;
          h += '<div class="ss-month"><div class="ss-mt">' + MONL[m0.getMonth()] + ' ' + m0.getFullYear() + '</div><div class="ss-grid">';
          'MTWTFSS'.split('').forEach(function (w) { h += '<div class="ss-wd">' + w + '</div>'; });
          for (var i = 0; i < lead; i++) h += '<span></span>';
          for (var d = 1; d <= days; d++) {
            var t = new Date(m0.getFullYear(), m0.getMonth(), d), cls = 'ss-day', past = t < TODAY;
            if (from && +t === +from || to && +t === +to) cls += ' is-end'; else if (from && to && t > from && t < to) cls += ' is-mid';
            h += '<button type="button" class="' + cls + '" data-t="' + (+t) + '"' + (past ? ' disabled style="opacity:.3;cursor:default"' : '') + '>' + d + '</button>';
          }
          h += '</div></div>';
        }
        h += '</div><div class="ss-foot"><button type="button" class="ss-clear">Clear</button><span class="ss-sum">' + (fmt(from, to) || 'Choose arrival and departure') + '</span><button type="button" class="ss-done">Done</button></div>';
        dPop.innerHTML = h;
        var fl = fWhen.getBoundingClientRect().left, w = dPop.offsetWidth, vw = document.documentElement.clientWidth;
        dPop.style.left = Math.min(0, vw - 16 - fl - w) + 'px';
      }
      dPop.addEventListener('click', function (e) {
        var b = e.target.closest('button'); if (!b || b.disabled) return;
        if (b.dataset.n) { view = new Date(view.getFullYear(), view.getMonth() + (+b.dataset.n), 1); draw(); return; }
        if (b.dataset.t) { var t = new Date(+b.dataset.t); if (!from || to || t < from) { from = t; to = null; } else { to = t; } draw(); return; }
        if (b.classList.contains('ss-clear')) { from = to = null; draw(); return; }
        if (b.classList.contains('ss-done')) { if (from) { setRange(from, to || from); dBtn.textContent = st.dates; } dPop.remove(); dPop = null; }
      });
      fWhen.appendChild(dPop); draw();
    };
    document.addEventListener('mousedown', function (e) { if (dPop && !fWhen.contains(e.target)) { dPop.remove(); dPop = null; } });
    fWhen.appendChild(dBtn);
    var count = (CITIES.filter(function (c) { return c[0] === st.dest; })[0] || [0, 0])[1];
    var fGo = field('\u00a0', 'flex:none');
    var goBtn = el('button', 'height:' + pillH + 'px;padding:0 ' + (lg ? 28 : 20) + 'px;border-radius:999px;border:0;background:#FF3C00;color:#000000;font:600 ' + (lg ? 15 : 13) + 'px/1 ' + H + ';cursor:pointer;white-space:nowrap;transition:background-color .15s ease', 'Search');
    goBtn.type = 'button';
    goBtn.onmouseenter = function () { goBtn.style.background = '#E63600'; }; goBtn.onmouseleave = function () { goBtn.style.background = '#FF3C00'; };
    goBtn.onclick = function () { if (!st.dest) { editDest(); return; } location.href = 'explore.html?city=' + encodeURIComponent(st.dest); };
    fGo.appendChild(goBtn);
    bar.appendChild(left); bar.appendChild(fWhen); bar.appendChild(fGo);
    host.appendChild(bar);
    if (lg) host.appendChild(el('div', 'font:400 14px/1.4 ' + H + ';color:rgba(0,0,0,.7);margin-top:12px', modeLine()));
  }
  function renderAll() { document.querySelectorAll('[data-ss]').forEach(render); }
  function init() {
    renderAll(); paintPairs();
    document.querySelectorAll('[data-dest]').forEach(function (d) { if (st.dest) d.textContent = st.dest; });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
